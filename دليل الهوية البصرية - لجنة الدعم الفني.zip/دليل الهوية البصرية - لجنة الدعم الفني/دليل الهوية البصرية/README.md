# Hisn Brand Kit · حزمة هوية حصن

Batch 1 · October 2026: logo, colors, typography, web basics.

## Folders

| Folder | Status | Contents |
|---|---|---|
| `01-guidelines/` | Pending | Guidelines PDF, exported from "Hisn Brand Guidelines Part 1" (Arabic). Short English version in a later batch. |
| `02-logo/svg/` | ✅ | 5 mark versions (gradient, teal, white, mono, black) + horizontal, vertical, full lockups × 6 colorways. |
| `02-logo/png/` | ✅ | Every SVG as transparent PNG at 512, 1024, 2048. |
| `02-logo/print/` | Pending | PDF / CMYK. Convert SVGs in Illustrator (CMYK values in guidelines §02). |
| `02-logo/social/` | ✅ | Profile picture, square and circle, 1024. |
| `03-colors/` | ✅ partial | `colors.json` (core, scales 50–900, gradients), `colors.ase` (Adobe swatches, core colors). `palette.pdf` pending. |
| `04-typography/` | ✅ | `fonts.md`: Google Fonts links, embed code, OFL license. Scale PDF pending. |
| `05-elements/` | Later batch | Crenellations, bricks, squares, hairline, patterns. |
| `06-icons/` | Later batch | currentColor SVGs + PNG 24/48/96. |
| `07-templates/` | Later batch | print, social, documents, presentation. |
| `08-sub-brands/` | Later batch | Hisnathon, Hisn Exhibition, Build the Fortress, Hisn Ambassadors. |
| `09-web/favicon/` | ✅ | `favicon.ico` (16/32/48), `favicon.svg`, PNG 16/32/48. |
| `09-web/app-icons/` | ✅ | `apple-touch-icon.png` (180), `icon-192.png`, `icon-512.png`, `site.webmanifest`. |
| `09-web/og-image/` | Later batch | 1200×630, Arabic and English. |
| `09-web/logo-web/` | ✅ partial | Minified mark SVGs. WebP pending. |
| `09-web/tokens/` | ✅ | `tokens.json`, `tokens.css` (light default; dark via `[data-theme="dark"]` or system preference). |
| `09-web/ui-kit/` | Later batch | Figma link + component previews. |

## Web quick start

```html
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="stylesheet" href="/tokens.css">
```

## Naming

Lowercase English with hyphens only, e.g. `hisn-lockup-horizontal-white.svg`. No spaces, no Arabic in filenames.

## Notes

- Lockup SVGs embed the wordmark font; convert text to outlines before print.
- Pantone references in the guidelines are approximate; confirm against a printed swatch.
- Empty folders contain `.gitkeep` to preserve the structure.
