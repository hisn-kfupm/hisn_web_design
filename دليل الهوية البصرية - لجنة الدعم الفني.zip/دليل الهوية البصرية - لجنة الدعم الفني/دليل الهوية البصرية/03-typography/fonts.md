# Hisn typography

- Arabic: IBM Plex Sans Arabic: https://fonts.google.com/specimen/IBM+Plex+Sans+Arabic
- English: IBM Plex Sans: https://fonts.google.com/specimen/IBM+Plex+Sans

Weights: Regular 400 · Medium 500 · SemiBold 600 · Bold 700

## License
Both families are published by IBM under the SIL Open Font License 1.1: free for commercial use, embedding and modification; the fonts may not be sold on their own.
https://openfontlicense.org

## Web embed
```html
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
```

Size scale: section 03 of the guidelines, and 09-web/tokens.
